// ------------------------------------------------------
// Aprende JavaFX con ejemplos
// Enlanzando propiedades y objetos gráficos
// ------------------------------------------------------

// Compilación
// javac --module-path /usr/share/openjfx/lib/ --add-modules javafx.controls Main.java

// Ejecución
// java --module-path /usr/share/openjfx/lib/ --add-modules javafx.controls Main

// Elimina el Warning
// export NO_AT_BRIDGE=1

// Librerias
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ReadOnlyStringProperty;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

// Función Main
public class Main extends Application 
{
    // Definimos 2 propiedades
    private final static String MY_PASS = "1234"; // El password
    private final static BooleanProperty accesoPermitido = new SimpleBooleanProperty(false);

    @Override
    public void start(Stage primaryStage) 
    {
        // Crea el objeto Usuario
        Usuario Usuario = new Usuario();

        // Crea un contenedor
        Group root = new Group();

        // Crea una escena
        Scene scene = new Scene(root, 320, 100);

        // Coloca el titulo en la ventana
        primaryStage.setTitle("Accediendo ...");

        // Establece la escena para la ventana principal
        primaryStage.setScene(scene);
        
        // Crea el texto (label)
        Text lblUsuarioNombre = new Text("");
        
        // Acá se enlaza; y esto es lo que hace el label tome el valor del objeto
        lblUsuarioNombre.textProperty().bind(Usuario.UsuarioNombreProperty());        
 
        // Crea el password field
        PasswordField passUsuarioPassword = new PasswordField();
        Usuario.passwordProperty().bind(passUsuarioPassword.textProperty());
        
        // Usuario hits the enter key
        passUsuarioPassword.setOnAction(actionEvent -> 
        {
            // Verifica si el acceso está concedido
            if (accesoPermitido.get()) 
            {
                // Despliega la informacion
                System.out.println("Acceso Permitido:"+ Usuario.getUsuarioNombre());
                System.out.println("Password        :"+ Usuario.getPassword());

                // Sale de la Aplicación
                Platform.exit();

            } 
            else 
            {
                // Indica en la ventana que no hubo acceso
                primaryStage.setTitle("Error en Acceso"); 
            }
        });
        
        // Método para controlar la captura en el password
        passUsuarioPassword.textProperty().addListener((obs, ov, nv) -> 
        {
            // Verifica si el password capturado es igual a MY_PASS
            boolean bAcceso = passUsuarioPassword.getText().equals(MY_PASS);
            accesoPermitido.set(bAcceso);
            if (bAcceso) 
            {
                // Elimina lo que haya en el titulo
                primaryStage.setTitle("Acceso Concedido");
            }
            else
            {
                primaryStage.setTitle("Accediendo ...");
            }
        });
        
        // Crea un contenedor
        VBox vBoxContenedor = new VBox(4);

        // Agrega los objetos al contenedor
        vBoxContenedor.getChildren().addAll(lblUsuarioNombre, passUsuarioPassword);
        vBoxContenedor.setLayoutX(12);
        vBoxContenedor.setLayoutY(12);

        // Agrega el Contenedor al Root
        root.getChildren().addAll(vBoxContenedor);

        // Muestra la Ventana
        primaryStage.show();
    }
    public static void main(String[] args) 
    {
        launch(args);
    }
}

// Clase Usuario
class Usuario 
{
   // Las propuedades de la Clase 
   private final ReadOnlyStringWrapper usuarioNombre;
   private       StringProperty        usuarioPassword;
   
   // Constructor
   public Usuario() 
   {
       usuarioNombre   = new ReadOnlyStringWrapper(this, "usuarioNombre", "Alumno:");
       usuarioPassword = new SimpleStringProperty(this,  "usuarioPassword", "");
   }
   
   // Getter
   public final String getUsuarioNombre() 
   {
       // Retorna el valor del usuario nombre
       return usuarioNombre.get();
   }

   // Retorna la Propiedad
   public ReadOnlyStringProperty UsuarioNombreProperty() 
   {
       // Retorna la propiedad
       return usuarioNombre.getReadOnlyProperty();
   }
   
   // Retorna el Password
   public final String getPassword() 
   {
       // Retorna el Valor del password
       return usuarioPassword.get();
   }

   // Retorna la propiedad del Password
   public StringProperty passwordProperty() 
   {
       // Retorna la propiedad
       return usuarioPassword;
   }
}