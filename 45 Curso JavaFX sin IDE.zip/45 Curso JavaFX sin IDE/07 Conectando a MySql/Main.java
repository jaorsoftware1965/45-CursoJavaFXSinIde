// ------------------------------------------------------
// Aprende JavaFX con ejemplos
// Conectando a MySql
// ------------------------------------------------------

// Compilación
// javac --module-path /usr/share/openjfx/lib/ --add-modules javafx.controls Main.java

// Ejecución
// java --module-path /usr/share/openjfx/lib/ --add-modules javafx.controls Main

// Elimina el Warning
// export NO_AT_BRIDGE=1

// Librerias
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.control.Button;
import javafx.stage.Stage;

// Función Main
public class Main extends Application 
{
    // Propiedades de la Clase    
    Connection conn=null;

    @Override
    public void start(Stage primaryStage) 
    {        
        // Creamos un Objeto de Usuario
        Usuario xUsuario = new Usuario();

        // Crea un contenedor de Grupo
        Group root = new Group();

        // Crea una escena
        Scene scene = new Scene(root, 280, 170);

        // Coloca el Título en la Ventana Principal
        primaryStage.setTitle("Inicio de Sesion");

        // Coloca la escena en la Ventana Principal
        primaryStage.setScene(scene);
        
        // Crea un objeto Text (label)
        Text lblUsuario = new Text();
        //lblUsuario.setText("Usuario:");
        // Enlazamos para lograr lo anterior
        lblUsuario.textProperty().bind(xUsuario.lblUsuarioProperty());
        
        // Crea un objeto TextField
        TextField txtUsuario = new TextField();
        // Enlazamos para ver si logramos obtener el usuario default
        // Si le colocas solo bind, no funciona la captura
        txtUsuario.textProperty().bindBidirectional(xUsuario.txtUsuarioProperty());


        // Crea un objeto Text (label)
        Text lblPassword = new Text();
        //lblPassword.setText("Password:");
        // Enlazamos para lograr lo anterior
        lblPassword.textProperty().bind(xUsuario.lblPasswordProperty());

        // Crea un objeto para el Password
        PasswordField passUsuario = new PasswordField();
        passUsuario.setPromptText("Password");
        
        // Esto enlaza y obtiene el password
        passUsuario.textProperty().bindBidirectional(xUsuario.txtPasswordProperty());
        
        // Creamos el botón de Aceptar
        Button btnAceptar = new Button();

        // Asignamos Texto al Botón
        btnAceptar.setText("Aceptar");
        btnAceptar.setMaxWidth(170);

        // Controlamos el Enter en el Usuario
        txtUsuario.setOnAction(actionEvent -> 
        {
            // Manda el Foco al password
            passUsuario.requestFocus();
        });

        // Controlamos el Enter en el Password
        passUsuario.setOnAction(actionEvent -> 
        {
            // Manda el Foco al botón de Aceptar
            btnAceptar.requestFocus();
        });

        // Controlamos el Enter en el Boton
        btnAceptar.setOnAction(actionEvent -> 
        {
            // Variable para el Query
            String sQuery = " SELECT nombre FROM usuarios";
            sQuery += " WHERE alias='"+txtUsuario.getText()+"'";
            sQuery += " AND   clave='"+passUsuario.getText()+"'";

            // Despliega la Sentencia
            System.out.println ("sQuery:"+sQuery);

            // Prepara el objeto para la Sentencia
            try 
            {
                // Crea el objeto para la sentencia
                Statement sentencia = conn.createStatement();

                // Ejecuta la Sentencia Sql
                ResultSet resultado = sentencia.executeQuery(sQuery);

                // Verifica que haya habido un resultado
                if (resultado.next())
                {
                    // Despliega el Nombre
                    System.out.println ("Nombre:"+resultado.getString(1));
                    
                    // Acceso concedido
                    primaryStage.setTitle("Acceso Concedido ...");
                }
                else
                {
                    // Error en Acceso
                    primaryStage.setTitle("Error en Acceso ...");
                }
            } 

            // Captura el Error
            catch (SQLException e) 
            {
                // Ocurrió un error
                System.out.println ("---------------------------------------");
                System.out.println ("Ocurrió un Error al Ejecutar Sentencia:");
                System.out.println(e.getMessage());
                System.out.println ("---------------------------------------");
                
                // TODO Auto-generated catch block
                //e.printStackTrace();
                exit(0);
            }                        
        });        

        // Define un Contenedor VerticalBox
        VBox vBoxContenedor = new VBox(5);
        vBoxContenedor.getChildren().addAll(lblUsuario, txtUsuario, lblPassword,passUsuario);
        vBoxContenedor.getChildren().addAll(btnAceptar);

        // Margen Izquierdo
        vBoxContenedor.setLayoutX(20);

        // Margen Derecho
        vBoxContenedor.setLayoutY(20);
        
        // Coloca el Contenedor en el root
        root.getChildren().addAll(vBoxContenedor);

        // Creas la conexión a MySql
        ConexionMySQL SQL = new ConexionMySQL();

        // Conectamos y obtenemos la conexión
        conn = SQL.conectarMySQL();

        // Muestra la Ventana
        primaryStage.show();
    }
    private void exit(int i) {
    }
    public static void main(String[] args) {
        launch(args);
    }
}