// ------------------------------------------------------
// Aprende JavaFX con ejemplos
// Diseño de Ventana de Inicio de Sesion
// ------------------------------------------------------

// Compilación
// javac --module-path /usr/share/openjfx/lib/ --add-modules javafx.controls Main.java

// Ejecución
// java --module-path /usr/share/openjfx/lib/ --add-modules javafx.controls Main

// Elimina el Warning
// export NO_AT_BRIDGE=1

// Librerias
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.control.Button;
import javafx.stage.Stage;

// Función Main
public class Main extends Application 
{

    @Override
    public void start(Stage primaryStage) 
    {        
        // Crea un contenedor de Grupo
        Group root = new Group();

        // Crea una escena
        Scene scene = new Scene(root, 270, 170);

        // Coloca el Título en la Ventana Principal
        primaryStage.setTitle("Inicio de Sesion");

        // Coloca la escena en la Ventana Principal
        primaryStage.setScene(scene);
        
        // Crea un objeto Text (label)
        Text lblUsuario = new Text();
        lblUsuario.setText("Usuario:");

        // Crea un objeto TextField
        TextField txtUsuario = new TextField();
        txtUsuario.setMaxWidth(200);

        // Crea un objeto Text (label)
        Text lblPassword = new Text();
        lblPassword.setText("Password:");
        

        // Crea un objeto para el Password
        PasswordField passUsuario = new PasswordField();
        passUsuario.setPromptText("Password");
        passUsuario.setMaxWidth(200);

        // Creamos el botón de Aceptar
        Button btnAceptar = new Button();

        // Asignamos Texto al Botón
        btnAceptar.setText("Aceptar");
        btnAceptar.setMaxWidth(170);
        

        // Define un Contenedor VerticalBox
        VBox vBoxContenedor = new VBox(5);
        vBoxContenedor.getChildren().addAll(lblUsuario, txtUsuario, lblPassword,passUsuario);
        vBoxContenedor.getChildren().addAll(btnAceptar);

        // Margen Izquierdo
        vBoxContenedor.setLayoutX(20);

        // Margen Derecho
        vBoxContenedor.setLayoutY(20);
        
        // Coloca el Contenedor en el root
        root.getChildren().addAll(vBoxContenedor);

        // Muestra la Ventana
        primaryStage.show();
        
    }
    public static void main(String[] args) {
        launch(args);
    }
}