// ------------------------------------------------------
// Aprende JavaFX con ejemplos
// Hola Mundo
// ------------------------------------------------------

// Compilación
// javac --module-path /usr/share/openjfx/lib/ --add-modules javafx.controls Main.java

// Ejecución
// java --module-path /usr/share/openjfx/lib/ --add-modules javafx.controls Main

// Elimina el Warning
// export NO_AT_BRIDGE=1

// Librerias a Utilizar
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;


// La Clase Principal
public class Main extends Application 
{

  @Override
  public void start(Stage primaryStage) 
  {
    // Creamos un botón
    Button btn = new Button();

    // Asignamos Texto al Botón
    btn.setText("Imprimir  'Hola Mundo'");

    // Establecemos la acción de click
    btn.setOnAction(new EventHandler<ActionEvent>() 
    {
      // Esta es la forma de controlar el Click
      @Override
      public void handle(ActionEvent event) 
      {
        // Mandamos un mensaje a la pantalla
        System.out.println("Hola Mundo !");
      }
    });

    // Creamos un contenedor
    StackPane root = new StackPane();

    // Añadimos al Contenedor el Botón
    root.getChildren().add(btn);

    // Creamos una Escena
    Scene scene = new Scene(root, 400, 200);

    // Coloca el titulo de la Ventana
    primaryStage.setTitle("Hola Mundo en JavaFx");

    // Ponemos la Escena
    primaryStage.setScene(scene);

    // La mostramos
    primaryStage.show();

  }

  // Función Principal
  public static void main(String[] args) 
  {    
    // Método de que lanza la aplicación
    launch(args);
  }
}