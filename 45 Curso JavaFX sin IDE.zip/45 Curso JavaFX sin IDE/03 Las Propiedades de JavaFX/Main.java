// ------------------------------------------------------
// Aprende JavaFX con ejemplos
// Las Propiedades de JavaFX
// ------------------------------------------------------

// Compilación
// javac --module-path /usr/share/openjfx/lib/ --add-modules javafx.controls Main.java

// Ejecución
// java --module-path /usr/share/openjfx/lib/ --add-modules javafx.controls Main

// Elimina el Warning
// export NO_AT_BRIDGE=1

// Las propiedades de JavaFX almacenan el estado interno de un control y nos 
// permiten escuchar el cambio de estado de los controles de la interfaz de 
// usuario de JavaFX.

// Las propiedades de JavaFX se pueden vincular entre sí. El comportamiento 
// de enlace permite a las propiedades sincronizar sus valores en función de 
// un valor modificado de otra propiedad.

// Hay dos tipos de propiedades de JavaFX:
//     Leer / escribir
//     Solo lectura

// Las propiedades de JavaFX sostienen valores y brindan soporte para cuando
// estas sufren cambios; soporte para invalidación y la capacidad de
// enlazar unos con otros.

// Todas las clases de propiedades de JavaFX se encuentran en el espacio de 
// nombres del paquete javafx.beans.property. *.

// La siguiente lista son clases de propiedad de uso común.
//     javafx.beans.property.SimpleBooleanProperty
//     javafx.beans.property.ReadOnlyBooleanWrapper
//     javafx.beans.property.SimpleintegerProperty
//     javafx.beans.property.ReadOnlyintegerWrapper
//     javafx.beans.property.SimpleDoubleProperty
//     javafx.beans.property.ReadOnlyDoubleWrapper
//     javafx.beans.property.SimpleStringProperty
//     javafx.beans.property.ReadOnlyStringWrapper

// Las propiedades con Simple son las clases de propiedad de lectura / escritura. 
// Las propiedades con ReadOnly son las propiedades de solo lectura.


// Librerias
import javafx.beans.property.ReadOnlyStringProperty;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

// Funcion Main
public class Main 
{
  public static void main(String[] args) 
  {
      // Creamos una propiedad Simple de Tipo String con un valor
      StringProperty password  = new SimpleStringProperty("nomelose");

      // Desplegamos el valor de la propiedad
      System.out.println(" StringProperty "  + password.get() );

      // Cambiamos el valor de la propiedad
      password.set("nolorecuerdo");

      // Desplegamos el valor de la propiedad
      System.out.println(" StringProperty "  + password.get());

      // Creamos una propiedad Simple Integer con valor 0
      SimpleIntegerProperty xEntero = new SimpleIntegerProperty(0);

      // Test de usarlo antes
      

      // Adding a change listener with anonymous inner class
      xEntero.addListener(new ChangeListener<Number>() 
      {
        @Override
        public void changed(ObservableValue<? extends Number> ov, Number oldVal,
                            Number newVal) 
        {
            System.out.println("old value:"+oldVal);
            System.out.println("new value:"+newVal);            
        }
      });

      // Adding a change listener with lambda expression
      xEntero.addListener((ObservableValue<? extends Number> ov, Number oldVal,
                           Number newVal) -> 
      {
          System.out.println("old value 2:"+oldVal);
          System.out.println("new value 2:"+newVal);
      });

      // Cambia el valor del Entero
      xEntero.set(13);
      xEntero.set(34);
      xEntero.set(89);
      System.out.println("xEntero:"+xEntero.getValue());
      System.out.println("xEntero:"+xEntero.get());


      // Definimos una propiedad String de Solo Lectura
      ReadOnlyStringWrapper  sVersion = new ReadOnlyStringWrapper("BeansVersion","NameVersion 3.4","Version 3.4");
      ReadOnlyStringProperty readOnlysVersion  = sVersion.getReadOnlyProperty();

      // Dejamos un espacio
      System.out.println("");

      System.out.println("Version 1:"+sVersion);
      System.out.println("get)"+sVersion.get());
      System.out.println("getBean)"+sVersion.getBean());
      System.out.println("getName)"+sVersion.getName());
      System.out.println("getValue)"+sVersion.getValue());
      System.out.println("getValueSafe)"+sVersion.getValueSafe());
      System.out.println("readOnly :"+readOnlysVersion);
      System.out.println("------------------------");

      // Modificamos el Valor
      sVersion.set("Version 3.5");

      System.out.println("Version 2:"+sVersion);
      System.out.println("get)"+sVersion.get());
      System.out.println("getBean)"+sVersion.getBean());
      System.out.println("getName)"+sVersion.getName());
      System.out.println("getValue)"+sVersion.getValue());
      System.out.println("getValueSafe)"+sVersion.getValueSafe());
      System.out.println("readOnly :"+readOnlysVersion);
  }
}