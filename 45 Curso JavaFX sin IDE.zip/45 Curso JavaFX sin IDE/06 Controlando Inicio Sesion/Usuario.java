
// ------------------------------------------------------
// Aprende JavaFX con ejemplos
// Clase Usuario para el Inicio de Sesión
// ------------------------------------------------------

// Librerias
import javafx.beans.property.ReadOnlyStringProperty;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

// Clase Usuario
class Usuario 
{
    // Propiedades de la Clase
    private ReadOnlyStringWrapper lblUsuario;    
    private StringProperty        txtUsuario;
    private ReadOnlyStringWrapper lblPassword;    
    private StringProperty        txtPassword;

    // Clase Usuario
    public Usuario() 
    {
        lblUsuario  = new ReadOnlyStringWrapper("Usuario:");
        txtUsuario  = new SimpleStringProperty("sa");
        lblPassword = new ReadOnlyStringWrapper("Password:");
        txtPassword = new SimpleStringProperty("root");
    }
    
    // Getter's
    // public final String getTxtUsuario() 
    // {
    //     // Retorna el Valor del Texto
    //     return txtUsuario.get();
    // }
    
    // public final String getTxtPassword() 
    // {
    //     // Retorna el Valor del Texto
    //     return txtPassword.get();
    // }
    

    // Retornando las propiedades
    public ReadOnlyStringProperty lblUsuarioProperty() 
    {
        return lblUsuario.getReadOnlyProperty();
    }

    public StringProperty txtUsuarioProperty() 
    {
        return txtUsuario;
    }

    public ReadOnlyStringProperty lblPasswordProperty() 
    {
        return lblPassword.getReadOnlyProperty();
    }

    public StringProperty txtPasswordProperty() 
    {
        // El error que me recuerda a Python
        return txtPassword;
    }
 }